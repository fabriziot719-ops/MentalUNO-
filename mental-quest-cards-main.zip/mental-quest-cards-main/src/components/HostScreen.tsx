import { useState, useEffect, useRef } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import { createPeer, generateRoomCode, getRoomUrl, type PeerMessage } from "@/lib/peerService";
import { generateCard, generateHand, type GameCard } from "@/lib/gameLogic";
import type Peer from "peerjs";
import type { DataConnection } from "peerjs";

interface HostScreenProps {
  onGameStart: (conn: DataConnection, mesa: GameCard, hand: GameCard[], peer: Peer) => void;
  onBack: () => void;
}

export function HostScreen({ onGameStart, onBack }: HostScreenProps) {
  const [roomCode, setRoomCode] = useState("---");
  const [status, setStatus] = useState("Creando sala...");
  const peerRef = useRef<Peer | null>(null);

  useEffect(() => {
    const code = generateRoomCode();
    setRoomCode(code);

    createPeer(code)
      .then((peer) => {
        peerRef.current = peer;
        setStatus("Esperando oponente...");

        peer.on("connection", (conn) => {
          setStatus("Oponente conectado. Iniciando...");
          conn.on("open", () => {
            const mesa = generateCard();
            const hostHand = generateHand();
            const guestHand = generateHand();

            const msg: PeerMessage = {
              tipo: "inicio",
              mesa,
              mano: guestHand,
            };
            conn.send(msg);

            setTimeout(() => onGameStart(conn, mesa, hostHand, peer), 500);
          });
        });
      })
      .catch(() => setStatus("Error al crear la sala."));

    return () => {
      peerRef.current?.destroy();
    };
  }, [onGameStart]);

  const url = getRoomUrl(roomCode);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-6 px-4">
      <h2 className="font-display text-2xl font-bold text-foreground">
        Código de Sala:&nbsp;
        <span className="text-primary">{roomCode}</span>
      </h2>

      <div className="bg-paper p-3">
        <QRCodeSVG value={url} size={200} bgColor="#F5F5F5" fgColor="#1A1D21" />
      </div>

      <p className="text-muted-foreground font-body text-sm max-w-xs text-center">
        {status}
      </p>
      <p className="text-muted-foreground font-body text-xs break-all max-w-xs text-center">
        {url}
      </p>

      <Button variant="menu-muted" size="lg" onClick={onBack}>
        Volver
      </Button>
    </div>
  );
}
