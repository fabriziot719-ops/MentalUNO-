interface BotStatusProps {
  bots: { name: string; cardCount: number; isActive: boolean }[];
}

export function BotStatus({ bots }: BotStatusProps) {
  return (
    <div className="flex gap-3 flex-wrap justify-center px-4 py-3">
      {bots.map((bot) => (
        <div
          key={bot.name}
          className={`px-5 py-2 border-2 font-display text-sm ${
            bot.isActive
              ? "border-primary bg-primary/10 text-foreground"
              : "border-border bg-secondary text-secondary-foreground"
          }`}
        >
          {bot.name}: <span className="font-bold">{bot.cardCount}</span>
        </div>
      ))}
    </div>
  );
}
