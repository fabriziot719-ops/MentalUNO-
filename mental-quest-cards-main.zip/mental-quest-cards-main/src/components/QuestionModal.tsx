import { motion, AnimatePresence } from "framer-motion";
import { preguntas } from "@/data/preguntas";
import { type GameCard, type CardColor } from "@/lib/gameLogic";
import { Button } from "@/components/ui/button";

const colorClasses: Record<CardColor, string> = {
  rojo: "bg-game-red text-paper",
  azul: "bg-game-blue text-paper",
  verde: "bg-game-green text-paper",
  amarillo: "bg-game-yellow text-graphite",
};

interface QuestionModalProps {
  card: GameCard | null;
  onAnswer: (correct: boolean) => void;
}

export function QuestionModal({ card, onAnswer }: QuestionModalProps) {
  if (!card) return null;

  const question = preguntas[card.qIndex];

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center bg-background/95"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className={`w-[85vw] max-w-lg flex flex-col border-2 border-foreground/20 ${colorClasses[card.color]}`}
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "tween", duration: 0.4 }}
        >
          {/* Card number header */}
          <div className="flex items-center justify-between px-6 py-4 border-b-2 border-foreground/10">
            <span className="font-display text-6xl font-bold opacity-30">{card.valor}</span>
            <span className="font-display text-xs font-bold uppercase tracking-widest opacity-60">
              {question.a}
            </span>
          </div>

          {/* Question body - paper colored */}
          <div className="bg-paper text-graphite p-6 flex flex-col gap-4">
            <h3 className="font-display text-lg font-bold leading-tight">
              {question.p}
            </h3>

            <div className="flex flex-col gap-2">
              {question.opciones.map((opcion, i) => (
                <Button
                  key={i}
                  variant="option"
                  size="full"
                  className="justify-start px-4 py-3 h-auto min-h-[48px]"
                  onClick={() => onAnswer(i === question.correcta)}
                >
                  {opcion}
                </Button>
              ))}
            </div>
          </div>

          {/* Card number footer */}
          <div className="flex items-center justify-end px-6 py-4 border-t-2 border-foreground/10">
            <span className="font-display text-6xl font-bold opacity-30 rotate-180">{card.valor}</span>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
