import { Button } from "@/components/ui/button";

interface RulesModalProps {
  open: boolean;
  onClose: () => void;
}

export function RulesModal({ open, onClose }: RulesModalProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/95">
      <div className="bg-paper text-graphite p-8 max-w-lg w-[90vw] border-2 border-border max-h-[80vh] overflow-y-auto">
        <h2 className="font-display text-2xl font-bold mb-6">Reglas de MentalUNO</h2>
        <ul className="space-y-3 font-body text-sm leading-relaxed mb-8">
          <li><strong>Objetivo:</strong> Quedarse sin cartas antes que los demás.</li>
          <li><strong>Coincidencia:</strong> Solo puedes jugar una carta si coincide en color o número con la que está en la mesa.</li>
          <li><strong>El Desafío:</strong> Cada carta tiene una pregunta de EXANI-II. Si respondes bien, la carta se queda en la mesa. Si fallas, robas una carta y pierdes el turno.</li>
          <li><strong>Mazo:</strong> Si no tienes ninguna carta que coincida, debes robar una del mazo y el turno pasará automáticamente.</li>
          <li><strong>Modo Individual:</strong> Juegas contra Bot A, B y C.</li>
        </ul>
        <Button variant="action" size="full" onClick={onClose}>
          Entendido
        </Button>
      </div>
    </div>
  );
}
