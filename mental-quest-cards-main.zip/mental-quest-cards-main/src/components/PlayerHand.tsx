import { type GameCard, canPlay } from "@/lib/gameLogic";
import { GameCardComponent } from "./GameCard";

interface PlayerHandProps {
  cards: GameCard[];
  mesa: GameCard | null;
  disabled: boolean;
  onCardClick: (index: number) => void;
}

export function PlayerHand({ cards, mesa, disabled, onCardClick }: PlayerHandProps) {
  return (
    <div className="w-full border-t-2 border-border bg-secondary/30 px-4 py-4">
      <div className="flex gap-2 overflow-x-auto pb-2 justify-center flex-wrap max-w-5xl mx-auto">
        {cards.map((card, i) => {
          const playable = mesa ? canPlay(card, mesa) : false;
          return (
            <GameCardComponent
              key={card.id}
              card={card}
              disabled={disabled || !playable}
              onClick={playable && !disabled ? () => onCardClick(i) : undefined}
              size="md"
            />
          );
        })}
      </div>
    </div>
  );
}
