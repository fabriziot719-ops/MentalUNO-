import { useState, useCallback, useRef, useEffect } from "react";
import { GameCardComponent } from "@/components/GameCard";
import { PlayerHand } from "@/components/PlayerHand";
import { BotStatus } from "@/components/BotStatus";
import { QuestionModal } from "@/components/QuestionModal";
import { Button } from "@/components/ui/button";
import { generateCard, generateHand, canPlay, botPlay, type GameCard } from "@/lib/gameLogic";

interface GameScreenProps {
  onExit: () => void;
}

export function GameScreen({ onExit }: GameScreenProps) {
  const [playerHand, setPlayerHand] = useState<GameCard[]>(() => generateHand());
  const [botHands, setBotHands] = useState<GameCard[][]>(() => [generateHand(), generateHand(), generateHand()]);
  const [mesa, setMesa] = useState<GameCard>(() => generateCard());
  const [currentTurn, setCurrentTurn] = useState(0); // 0=player, 1-3=bots
  const [questionCard, setQuestionCard] = useState<GameCard | null>(null);
  const [pendingIndex, setPendingIndex] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState<string | null>(null);
  const botTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isPlayerTurn = currentTurn === 0;

  const advanceTurn = useCallback((from: number) => {
    const next = (from + 1) % 4;
    setCurrentTurn(next);
  }, []);

  // Bot AI
  useEffect(() => {
    if (currentTurn === 0 || gameOver) return;

    botTimerRef.current = setTimeout(() => {
      const botIdx = currentTurn - 1;
      setBotHands((prev) => {
        const hands = prev.map((h) => [...h]);
        const hand = hands[botIdx];
        const playIdx = botPlay(hand, mesa);

        if (playIdx !== null) {
          // Bot answers correctly 60% of the time
          const correct = Math.random() < 0.6;
          if (correct) {
            const played = hand.splice(playIdx, 1)[0];
            setMesa(played);
            if (hand.length === 0) {
              setGameOver(`FIN DE LA PARTIDA — Bot ${String.fromCharCode(65 + botIdx)} gana`);
            }
          } else {
            hand.push(generateCard());
          }
        } else {
          hand.push(generateCard());
        }

        hands[botIdx] = hand;
        return hands;
      });
      advanceTurn(currentTurn);
    }, 1200);

    return () => {
      if (botTimerRef.current) clearTimeout(botTimerRef.current);
    };
  }, [currentTurn, mesa, gameOver, advanceTurn]);

  const handleCardClick = (index: number) => {
    const card = playerHand[index];
    if (canPlay(card, mesa)) {
      setPendingIndex(index);
      setQuestionCard(card);
    }
  };

  const handleAnswer = (correct: boolean) => {
    setQuestionCard(null);
    if (correct && pendingIndex !== null) {
      const played = playerHand[pendingIndex];
      const newHand = playerHand.filter((_, i) => i !== pendingIndex);
      setPlayerHand(newHand);
      setMesa(played);
      if (newHand.length === 0) {
        setGameOver("VICTORIA");
        return;
      }
    } else {
      setPlayerHand((prev) => [...prev, generateCard()]);
    }
    setPendingIndex(null);
    advanceTurn(0);
  };

  const handleDraw = () => {
    setPlayerHand((prev) => [...prev, generateCard()]);
    advanceTurn(0);
  };

  if (gameOver) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-8 px-4">
        <h1 className="font-display text-5xl md:text-7xl font-bold text-foreground tracking-tight">
          {gameOver}
        </h1>
        <Button variant="menu" size="xl" onClick={onExit}>
          Volver al Menú
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Top: Bot status */}
      <BotStatus
        bots={botHands.map((hand, i) => ({
          name: `Bot ${String.fromCharCode(65 + i)}`,
          cardCount: hand.length,
          isActive: currentTurn === i + 1,
        }))}
      />

      {/* Turn indicator */}
      <div className={`mx-auto px-8 py-3 font-display text-sm font-bold tracking-widest uppercase ${
        isPlayerTurn ? "bg-game-green text-paper" : "bg-destructive text-paper"
      }`}>
        {isPlayerTurn ? "Tu turno" : `Turno de Bot ${String.fromCharCode(64 + currentTurn)}`}
      </div>

      {/* Middle: Mesa */}
      <div className="flex-1 flex flex-col items-center justify-center gap-6">
        <GameCardComponent card={mesa} size="lg" />
        <Button
          variant="menu-muted"
          size="lg"
          onClick={handleDraw}
          disabled={!isPlayerTurn}
        >
          Robar del Mazo
        </Button>
      </div>

      {/* Bottom: Player hand */}
      <PlayerHand
        cards={playerHand}
        mesa={mesa}
        disabled={!isPlayerTurn}
        onCardClick={handleCardClick}
      />

      {/* Question modal */}
      <QuestionModal card={questionCard} onAnswer={handleAnswer} />
    </div>
  );
}
