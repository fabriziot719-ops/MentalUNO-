import { type CardColor, type GameCard } from "@/lib/gameLogic";
import { cn } from "@/lib/utils";

const colorClasses: Record<CardColor, string> = {
  rojo: "bg-game-red text-paper",
  azul: "bg-game-blue text-paper",
  verde: "bg-game-green text-paper",
  amarillo: "bg-game-yellow text-graphite",
};

interface GameCardComponentProps {
  card: GameCard;
  onClick?: () => void;
  disabled?: boolean;
  size?: "sm" | "md" | "lg";
}

export function GameCardComponent({ card, onClick, disabled, size = "md" }: GameCardComponentProps) {
  const sizeClasses = {
    sm: "w-14 h-20 text-lg",
    md: "w-20 h-28 text-3xl",
    lg: "w-24 h-36 text-4xl",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "font-display font-bold border-2 border-foreground/20 flex items-center justify-center transition-colors",
        colorClasses[card.color],
        sizeClasses[size],
        disabled && "opacity-40 grayscale cursor-not-allowed",
        !disabled && onClick && "hover:border-primary cursor-pointer",
      )}
    >
      {card.valor}
    </button>
  );
}
