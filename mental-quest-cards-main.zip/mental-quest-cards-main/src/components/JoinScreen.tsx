import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { createPeer, connectToPeer, type PeerMessage } from "@/lib/peerService";
import type { GameCard } from "@/lib/gameLogic";
import type Peer from "peerjs";
import type { DataConnection } from "peerjs";

interface JoinScreenProps {
  initialCode?: string;
  onGameStart: (conn: DataConnection, mesa: GameCard, hand: GameCard[], peer: Peer) => void;
  onBack: () => void;
}

export function JoinScreen({ initialCode, onGameStart, onBack }: JoinScreenProps) {
  const [code, setCode] = useState(initialCode || "");
  const [status, setStatus] = useState("");
  const [connecting, setConnecting] = useState(false);
  const peerRef = useRef<Peer | null>(null);

  const handleConnect = async () => {
    if (code.length < 4) return;
    setConnecting(true);
    setStatus("Conectando...");

    try {
      const peer = await createPeer();
      peerRef.current = peer;
      const conn = await connectToPeer(peer, code.toUpperCase());

      setStatus("Conectado. Esperando inicio...");

      conn.on("data", (data) => {
        const msg = data as PeerMessage;
        if (msg.tipo === "inicio") {
          onGameStart(conn, msg.mesa, msg.mano, peer);
        }
      });
    } catch {
      setStatus("No se pudo conectar. Verifica el código.");
      setConnecting(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-6 px-4">
      <h2 className="font-display text-2xl font-bold text-foreground">Ingresar Código</h2>

      <input
        type="text"
        value={code}
        onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 4))}
        placeholder="CÓDIGO"
        maxLength={4}
        className="bg-secondary text-foreground font-display text-3xl text-center tracking-[0.3em] w-48 py-4 border-2 border-border focus:border-primary outline-none"
      />

      {status && (
        <p className="text-muted-foreground font-body text-sm">{status}</p>
      )}

      <div className="flex flex-col gap-3 w-full max-w-xs">
        <Button
          variant="menu"
          size="full"
          onClick={handleConnect}
          disabled={code.length < 4 || connecting}
        >
          Conectar
        </Button>
        <Button variant="menu-muted" size="full" onClick={onBack}>
          Volver
        </Button>
      </div>
    </div>
  );
}
