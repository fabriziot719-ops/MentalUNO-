import { useState, useCallback, useEffect, useRef } from "react";
import { GameCardComponent } from "@/components/GameCard";
import { PlayerHand } from "@/components/PlayerHand";
import { QuestionModal } from "@/components/QuestionModal";
import { Button } from "@/components/ui/button";
import { generateCard, canPlay, type GameCard } from "@/lib/gameLogic";
import type { PeerMessage } from "@/lib/peerService";
import type { DataConnection } from "peerjs";

interface MultiplayerGameScreenProps {
  connection: DataConnection;
  initialMesa: GameCard;
  initialHand: GameCard[];
  isHost: boolean;
  onExit: () => void;
}

export function MultiplayerGameScreen({
  connection,
  initialMesa,
  initialHand,
  isHost,
  onExit,
}: MultiplayerGameScreenProps) {
  const [playerHand, setPlayerHand] = useState<GameCard[]>(initialHand);
  const [mesa, setMesa] = useState<GameCard>(initialMesa);
  const [myTurn, setMyTurn] = useState(isHost); // Host goes first
  const [opponentCards, setOpponentCards] = useState(7);
  const [questionCard, setQuestionCard] = useState<GameCard | null>(null);
  const [pendingIndex, setPendingIndex] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState<string | null>(null);
  const mesaRef = useRef(mesa);

  useEffect(() => {
    mesaRef.current = mesa;
  }, [mesa]);

  useEffect(() => {
    const handler = (data: unknown) => {
      const msg = data as PeerMessage;
      switch (msg.tipo) {
        case "jugada":
          setMesa(msg.carta);
          setOpponentCards((c) => c - 1);
          setMyTurn(true);
          break;
        case "paso":
          setOpponentCards((c) => c + 1);
          setMyTurn(true);
          break;
        case "turno":
          setMyTurn(true);
          break;
        case "fin":
          setGameOver(msg.mensaje);
          break;
      }
    };

    connection.on("data", handler);
    return () => {
      connection.off("data", handler);
    };
  }, [connection]);

  const handleCardClick = (index: number) => {
    const card = playerHand[index];
    if (canPlay(card, mesa)) {
      setPendingIndex(index);
      setQuestionCard(card);
    }
  };

  const handleAnswer = (correct: boolean) => {
    setQuestionCard(null);
    if (correct && pendingIndex !== null) {
      const played = playerHand[pendingIndex];
      const newHand = playerHand.filter((_, i) => i !== pendingIndex);
      setPlayerHand(newHand);
      setMesa(played);

      if (newHand.length === 0) {
        setGameOver("VICTORIA");
        connection.send({ tipo: "fin", mensaje: "FIN DE LA PARTIDA — Tu oponente gana" } as PeerMessage);
        return;
      }

      connection.send({ tipo: "jugada", carta: played } as PeerMessage);
    } else {
      const newCard = generateCard();
      setPlayerHand((prev) => [...prev, newCard]);
      connection.send({ tipo: "paso" } as PeerMessage);
    }
    setPendingIndex(null);
    setMyTurn(false);
  };

  const handleDraw = () => {
    setPlayerHand((prev) => [...prev, generateCard()]);
    connection.send({ tipo: "paso" } as PeerMessage);
    setMyTurn(false);
  };

  if (gameOver) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-8 px-4">
        <h1 className="font-display text-5xl md:text-7xl font-bold text-foreground tracking-tight text-center">
          {gameOver}
        </h1>
        <Button variant="menu" size="xl" onClick={onExit}>
          Volver al Menú
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Opponent status */}
      <div className="flex justify-center px-4 py-3">
        <div className={`px-5 py-2 border-2 font-display text-sm ${
          !myTurn ? "border-primary bg-primary/10 text-foreground" : "border-border bg-secondary text-secondary-foreground"
        }`}>
          Oponente: <span className="font-bold">{opponentCards}</span> cartas
        </div>
      </div>

      {/* Turn indicator */}
      <div className={`mx-auto px-8 py-3 font-display text-sm font-bold tracking-widest uppercase ${
        myTurn ? "bg-game-green text-paper" : "bg-destructive text-paper"
      }`}>
        {myTurn ? "Tu turno" : "Turno del oponente"}
      </div>

      {/* Mesa */}
      <div className="flex-1 flex flex-col items-center justify-center gap-6">
        <GameCardComponent card={mesa} size="lg" />
        <Button variant="menu-muted" size="lg" onClick={handleDraw} disabled={!myTurn}>
          Robar del Mazo
        </Button>
      </div>

      {/* Player hand */}
      <PlayerHand cards={playerHand} mesa={mesa} disabled={!myTurn} onCardClick={handleCardClick} />

      <QuestionModal card={questionCard} onAnswer={handleAnswer} />
    </div>
  );
}
