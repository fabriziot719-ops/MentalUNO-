import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RulesModal } from "@/components/RulesModal";
import { GameScreen } from "@/components/GameScreen";
import { HostScreen } from "@/components/HostScreen";
import { JoinScreen } from "@/components/JoinScreen";
import { MultiplayerGameScreen } from "@/components/MultiplayerGameScreen";
import type { GameCard } from "@/lib/gameLogic";
import type Peer from "peerjs";
import type { DataConnection } from "peerjs";
import logo from "@/assets/logo.png";

type Screen = "menu" | "solo" | "host" | "join" | "multiplayer";

interface MultiplayerState {
  connection: DataConnection;
  mesa: GameCard;
  hand: GameCard[];
  isHost: boolean;
  peer: Peer;
}

const Index = () => {
  const [screen, setScreen] = useState<Screen>("menu");
  const [rulesOpen, setRulesOpen] = useState(false);
  const [mpState, setMpState] = useState<MultiplayerState | null>(null);
  const [joinCode, setJoinCode] = useState<string | undefined>();

  // Check URL for ?join=CODE
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("join");
    if (code) {
      setJoinCode(code.toUpperCase());
      setScreen("join");
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  const handleHostStart = useCallback((conn: DataConnection, mesa: GameCard, hand: GameCard[], peer: Peer) => {
    setMpState({ connection: conn, mesa, hand, isHost: true, peer });
    setScreen("multiplayer");
  }, []);

  const handleGuestStart = useCallback((conn: DataConnection, mesa: GameCard, hand: GameCard[], peer: Peer) => {
    setMpState({ connection: conn, mesa, hand, isHost: false, peer });
    setScreen("multiplayer");
  }, []);

  const handleExit = useCallback(() => {
    mpState?.connection?.close();
    mpState?.peer?.destroy();
    setMpState(null);
    setScreen("menu");
  }, [mpState]);

  if (screen === "solo") {
    return <GameScreen onExit={() => setScreen("menu")} />;
  }

  if (screen === "host") {
    return <HostScreen onGameStart={handleHostStart} onBack={() => setScreen("menu")} />;
  }

  if (screen === "join") {
    return <JoinScreen initialCode={joinCode} onGameStart={handleGuestStart} onBack={() => setScreen("menu")} />;
  }

  if (screen === "multiplayer" && mpState) {
    return (
      <MultiplayerGameScreen
        connection={mpState.connection}
        initialMesa={mpState.mesa}
        initialHand={mpState.hand}
        isHost={mpState.isHost}
        onExit={handleExit}
      />
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-2 px-4">
      <img src={logo} alt="MentalUNO FAC Games" className="w-64 md:w-80 mb-6" />
      <p className="text-muted-foreground font-body text-sm tracking-widest uppercase mb-10">
        Desafío Académico EXANI-II
      </p>

      <div className="flex flex-col gap-3 w-full max-w-xs">
        <Button variant="menu" size="full" onClick={() => setScreen("solo")}>
          Individual vs 3 Bots
        </Button>
        <Button variant="menu" size="full" onClick={() => setScreen("host")}>
          Crear Sala Multijugador
        </Button>
        <Button variant="menu-secondary" size="full" onClick={() => setScreen("join")}>
          Unirse a Sala
        </Button>
        <Button variant="menu-muted" size="full" onClick={() => setRulesOpen(true)}>
          Reglas del Juego
        </Button>
      </div>

      <RulesModal open={rulesOpen} onClose={() => setRulesOpen(false)} />
    </div>
  );
};

export default Index;
