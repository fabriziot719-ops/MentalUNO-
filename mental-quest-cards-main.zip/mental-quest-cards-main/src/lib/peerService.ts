import Peer, { DataConnection } from "peerjs";
import { type GameCard } from "@/lib/gameLogic";

export type PeerMessage =
  | { tipo: "inicio"; mesa: GameCard; mano: GameCard[] }
  | { tipo: "jugada"; carta: GameCard }
  | { tipo: "paso" }
  | { tipo: "turno" }
  | { tipo: "fin"; mensaje: string };

export function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function createPeer(id?: string): Promise<Peer> {
  return new Promise((resolve, reject) => {
    const peer = new Peer(id ? `mentaluno-${id}` : undefined);
    peer.on("open", () => resolve(peer));
    peer.on("error", (err) => reject(err));
  });
}

export function connectToPeer(peer: Peer, roomCode: string): Promise<DataConnection> {
  return new Promise((resolve, reject) => {
    const conn = peer.connect(`mentaluno-${roomCode}`, { reliable: true });
    conn.on("open", () => resolve(conn));
    conn.on("error", (err) => reject(err));
    setTimeout(() => reject(new Error("Tiempo de espera agotado")), 10000);
  });
}

export function getRoomUrl(code: string): string {
  return `${window.location.origin}?join=${code}`;
}
