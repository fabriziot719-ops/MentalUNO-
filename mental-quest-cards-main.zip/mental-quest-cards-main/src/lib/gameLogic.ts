import { preguntas } from "@/data/preguntas";

export type CardColor = "rojo" | "azul" | "verde" | "amarillo";

export interface GameCard {
  color: CardColor;
  valor: string;
  qIndex: number;
  id: string;
}

let cardIdCounter = 0;

export function generateCard(): GameCard {
  const colores: CardColor[] = ["rojo", "azul", "verde", "amarillo"];
  return {
    color: colores[Math.floor(Math.random() * 4)],
    valor: Math.floor(Math.random() * 10).toString(),
    qIndex: Math.floor(Math.random() * preguntas.length),
    id: `card-${++cardIdCounter}-${Date.now()}`,
  };
}

export function generateHand(count: number = 7): GameCard[] {
  return Array.from({ length: count }, () => generateCard());
}

export function canPlay(card: GameCard, mesa: GameCard): boolean {
  return card.color === mesa.color || card.valor === mesa.valor;
}

export function botPlay(hand: GameCard[], mesa: GameCard): number | null {
  const playable = hand.findIndex((c) => canPlay(c, mesa));
  return playable >= 0 ? playable : null;
}
